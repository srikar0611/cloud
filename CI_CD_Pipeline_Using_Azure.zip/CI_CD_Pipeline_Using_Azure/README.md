# hello-pipelines
Simple set of .Net Core 3.0 projects used to try out Azure Pipelines concepts.
